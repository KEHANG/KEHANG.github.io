function obj = objFun(x)
% x(1) = tau
% x(2) = temperature
% x(3) = [T]_0
% x(4) = [CH3O]_0
% x(5) = [CH3OH]_0
% x(6) = [T]
% x(7) = [CH3O]
% x(8) = [CH3OH]
% x(9) = [D]
% x(10) = k (the kinetic coefficient)

obj = -x(9)/x(3); % molar yield of D
end