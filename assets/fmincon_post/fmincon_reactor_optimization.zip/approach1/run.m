% give the following initial guess for the optimal solution
% tau = 1
% temperature = 300K
% [T]0 = 4
% [C3H0]0 = 1
% [CH3OH]0 = 6
% [T] = 1
% [CH3O] = 1
% [CH3OH] = 1
% [D] = 1
% k = 1
x0 = [1,300,4,1,6,1,1,1,1,1];
[x,fval] = fmincon(@objFun, x0, [], [], [], [], [], [], @allcon)